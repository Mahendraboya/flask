from flask import Flask,redirect,url_for,render_template,request,flash 

from db import Register,Base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from flask_login import LoginManager,current_user,login_user,logout_user,login_required




app=Flask(__name__)
app.secret_key='1234'
login_manager=LoginManager(app)
login_manager.login_view='login'
login_manager.logi_message_category='info'

engine=create_engine('sqlite:///mydb.db',connect_args={'check_same_thread':False},echo=True)
Base.metadata.bind =engine
DBsession=sessionmaker(bind=engine)
session=DBsession()


@login_manager.user_loader
def load_user(user_id):
	return session.query(Register).get(int(user_id))

@app.route('/about')
def about():
	return render_template('about.html')

@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/home')
def home():
	data=session.query(Register).all()
	return render_template('home.html',reg=data)

@app.route('/register',methods=['POST','GET'])
def register():
 	if request.method=="POST":
 		newData=Register(name=request.form['uname'],
 			email=request.form['uemail'],
 			pword=request.form['pword'])
 		session.add(newData)
 		session.commit()
 		return redirect(url_for('login'))
 	else:
 		return render_template('register.html')


@login_required
@app.route("/login",methods=['POST','GET'])
def login():
	
		if request.method=='POST':
			user=session.query(Register).filter_by(
				email=request.form['email'],
				pword=request.form['pword']).first()
			if user:
				login_user(user)
				return redirect(url_for('index'))
			else:
				flash('Login failed')
		else:
			return render_template('login.html')



@app.route("/edit/<int:reg_id>",methods=['POST','GET'])
def editdata(reg_id):
	edit_data=session.query(Register).filter_by(id=reg_id).one()
	if request.method=="POST":
		edit_data.name=request.form['uname']
		edit_data.email=request.form['uemail']
		edit_data.pword=request.form['pword']
		session.add(edit_data)
		sesion:commit()
		flash("dataupdated successfully")
		return redirect(url_for('home'))
	else:
		return render_template('edit.html',edata=edit_data)
		
@app.route("/delete/<int:reg_id>",methods=['POST','GET'])
def deletedata(reg_id):
	delete_data=session.query(Register).filter_by(id=reg_id).one()
	if request.method=="POST":
		session.delete(delete_data)
		sesion:commit()
		flash("datadeleted successfully")
		return redirect(url_for('home'))
	else:
		return render_template('delete.html',ddata=delete_data)


@app.route('/logout')
def logout():
	logout_user()
	return redirect(url_for('index'))
app.run(debug=True)